---
name: ai-video-realism
description: Beginner workflow for realistic AI video - character/prop/location image prompts, Seedance video prompts, shot lists, 3D blocking previz, and compositing UI onto blank screens.
---

# AI Video Realism 

Helps a beginner make realistic AI video end to end, the way it's taught in the "AI Video Realism" tutorial:
assets first, then video, then advanced control with 3D blocking and motion-graphics UI.
Tools assumed: OpenArt with Seedream 5.0 Pro (images) and Seedance 2.5 (video). Works in the Claude app.

## Pick the mode from the request, then read only that reference file

| User wants | Mode | Read |
|---|---|---|
| a character sheet, their own face as a character, props/vehicles, a location/environment | Assets | `references/assets.md` |
| a prompt to turn images (and maybe a blocking clip) into video | Video prompts | `references/video.md` |
| a shot list from an idea, or a 3D blocking/storyboard animation | Shot list + blocking | `references/blocking.md` |
| UI/screen content put onto blank monitors in their videos | UI overlay | `references/ui_overlay.md` |

If the user is starting from scratch, walk them through in order: idea -> shot list -> assets -> (blocking) ->
video prompts -> UI overlay -> edit. Ask one short question at a time only when something essential is missing
(e.g. the character's look, which reference image is which). Otherwise just produce the output.

## Before rendering anything (3D blocking, UI overlay)
These modes run Python. Before the first render, check that you can run code (e.g. run `python3 --version`).
If you have no code tool, or it fails, don't just say you can't do it — tell the user, in two lines:

> To render this, turn on code execution: **Settings → Capabilities → "Code execution and file creation"**
> (on Enterprise plans an organization Owner must first enable it under Admin settings → Capabilities).
> Then start a new chat and send your request again.

Prompt-writing modes (assets, video prompts, shot lists) don't need this.

## House style for every prompt you write
- Short, plain, literal sentences. Same voice as the worked examples. No hype words.
- Labelled structure, always in the same order (see each reference file).
- Specific, slightly imperfect real-world details (skin texture, wear, loose hair, creases) — they sell realism.
- "Shot on 35mm film." Plain grey barren outdoor background for asset sheets.
- Say what must NOT appear or change ("No text", "Keep the monitor screen blank", "NO lamp at the desk").
- Tag references exactly as OpenArt numbers them: `@image1`, `@image2`..., `@video1`.
- Put every prompt inside its own fenced code block (```), so it keeps its line breaks and gets a one-click copy button, then list the OpenArt settings under it. Assume the user is on desktop.

## Output conventions
- Prompts: give the prompt, then one line of settings (model, aspect, resolution/length, audio on/off), then at
  most one tip.
- Videos you render (blocking, composites): full-length, keep the source frame rate, MP4 (H.264), plus a short
  note of what's in the file. Show a contact sheet or a still before long renders so the user can redirect early.
- Scripts live in `scripts/`: `blocking.py` + `render_blocking.py` (3D previz), `screen_comp.py` (UI overlay),
  `example_scene.py` (a complete blocking scene to copy from).
