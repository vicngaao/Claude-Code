# Asset prompts (characters, props, locations)

High quality assets = high quality videos. Everything the video model sees later comes from these images, so they carry most of the realism.

## Tool settings (OpenArt)
- Model: **Seedream 5.0 Pro** (Byte Plus). 16:9, 2K.
- Seedream = better visual style and colour. GPT Image 2.5 = slightly more realistic faces and textures, follows prompts closely, but looks flat. Default to Seedream; offer GPT Image 2.5 if faces come out plasticky.
- Seedream's weakness is CGI-looking people in blank studio backdrops. Fix: always a **plain empty grey barren OUTDOOR background** with soft flat diffuse light.
- Reference images are tagged in the prompt as `@image1`, `@image2` ... in the order they were uploaded.

## House style for every asset prompt
- Plain, literal sentences. No hype words ("stunning", "masterpiece", "8k").
- Open with "Generate a set of real photos of..." / "Real photographs of..." / "Create a photorealistic cinematic still...".
- Always state background, lighting and "Shot on 35mm film" (character sheets may add "kodak portra").
- Describe things in the order the eye reads them: overall -> build -> hair -> clothing top to bottom -> small details (wear, patches, gloves, jewellery).
- Add the specific, slightly imperfect details beginners leave out: natural skin texture, freckles, loose strands of hair, creases, frayed cuffs, scratches, dirt.
- End with exclusions: "No text", "no logos, no numbers", "No people" where relevant.

---

## 1. Character sheet

Ask the user (briefly): who the character is in the story, age, heritage/look, build, hair, outfit, mood. If it is the user themself, also ask for 2-3 clear photos of their face (front + side) and follow section 2.

### Template
```
Generate a set of real photos of [a young woman / the young man] laid out in columns. Keep the same face, hair and outfit in every panel. Plain empty grey barren outdoor background. Soft, even, flat diffuse lighting. Shot on 35mm film.
The LEFT column is split horizontally into two stacked panels of equal height (top and bottom), the CENTER and RIGHT columns are each one full-height panel.
Character, identical in all panels: [age, heritage, skin with clear natural skin texture, face details, eyes, brows, jaw]. Her/His expression: [expression].
She/He has a [build] build with a [posture] posture.
She/He has [hair: colour, length, texture, how it's styled or tied, loose strands], natural and slightly messy, fully visible and uncovered.
She/He wears [outfit top to bottom, with wear details and accessories].
Panels:
- Left column, TOP, FRONTAL HEADSHOT: head and shoulders, front view, both ears visible, nose centered, eyes looking straight into the lens, [what's visible at the neckline].
- Left column, BOTTOM, SIDE PROFILE HEADSHOT: the same head-and-shoulders crop and scale as the top panel, head turned a three-quarter profile view. Same expression.
- Center, FULL-BODY FRONT: framed from the neck down, with the head cropped at the base of the neck, standing in a relaxed upright pose, arms hanging naturally at her/his sides, both hands visible and empty, facing the camera; [key outfit pieces] clearly visible.
- Right, FULL-BODY BACK: framed from the neck down at the same crop height, standing straight, facing directly away, showing [back of the outfit].
Both headshot panels at identical scale with the head at the same height. Both body panels at identical scale. The face appears only in the two left-column headshots; the center and right panels show clothing and body proportions.
No text, shot on 35mm film.
```
Rules: one face, one outfit; never cover the head (scarves "around her neck and shoulders only, never over her head"); hands visible and empty in body panels.

### Worked example - Female pilot
```
Generate a set of real photos of a young woman laid out in columns. Keep the same face, hair and outfit in every panel. Plain empty grey barren outdoor background. Soft, even, flat diffuse lighting. Shot on 35mm film.
The LEFT column is split horizontally into two stacked panels of equal height (top and bottom), the CENTER and RIGHT columns are each one full-height panel.
Character, identical in all panels: a 25-year-old woman of Middle Eastern heritage with tan skin and clear natural skin texture, light freckles across her nose and cheeks, striking light hazel-green eyes, strong dark eyebrows and a defined jaw. Her expression: guarded and self-assured, a slight half-smile.
She has a lean, athletic, medium-height build with a confident upright posture.
She has long, thick, dark brown wavy hair falling past her shoulders, the top half loosely tied back with a thin leather cord, a few wind-blown strands framing her face, natural and slightly messy, fully visible and uncovered.
She wears a sun-faded rust-red canvas jacket, hip length, worn open, with mismatched patches on the sleeves and frayed cuffs, over a dusty cream tunic. A loosely wrapped sand-colored shemagh scarf is draped around her neck and shoulders only, never over her head. She wears a leather cord necklace with a small brass compass pendant, a dark brown leather chest harness with small pouches over the jacket, loose sand-colored trousers wrapped at the shins with cloth strips, worn tan desert boots, and dark brown leather gloves with the right index finger cut off.
Panels:
- Left column, TOP, FRONTAL HEADSHOT: head and shoulders, front view, both ears visible, nose centered, eyes looking straight into the lens, the shemagh around her neck and the jacket collar visible at the neckline, hair falling over her shoulders.
- Left column, BOTTOM, SIDE PROFILE HEADSHOT: the same head-and-shoulders crop and scale as the top panel, head turned a three-quarter profile view, the leather-tied half-up hair and its length clearly visible. Same expression.
- Center, FULL-BODY FRONT: framed from the neck down, with the head cropped at the base of the neck, standing in a relaxed upright pose, arms hanging naturally at her sides, both gloved hands visible and empty, facing the camera; the open rust-red jacket, cream tunic, compass pendant, chest harness, wrapped trousers and boots clearly visible.
- Right, FULL-BODY BACK: framed from the neck down at the same crop height, standing straight, facing directly away, showing the back of the patched rust-red jacket, the harness straps, the ends of her long hair and the shemagh, the trousers and the heels of the boots.
Both headshot panels at identical scale with the head at the same height. Both body panels at identical scale. The face appears only in the two left-column headshots; the center and right panels show clothing and body proportions.
No text, shot on 35mm film.
```

---

## 2. A real person (yourself) as the character

Seedream alters faces slightly, so never let it invent the face. Two steps:

**Step A - body sheet from a reference photo** (upload one clear photo as @image1). Same template as above, with: "Character, identical in all panels: the man from the reference photo, ..." and hair described "exactly as in the reference photo". Use this sheet only for the clothing and body.

Worked example - Male office worker (body sheet):
```
Generate a set of real photos of the young man laid out in columns. Keep the same face, hair and office outfit in every panel. Plain empty grey barren outdoor background. Soft, even, overcast, flat diffuse lighting. Shot on 35 mm film.
The LEFT column is split horizontally into two stacked panels of equal height (top and bottom), the CENTER and RIGHT columns are each one full-height panel.
Character, identical in all panels: the man from the reference photo, a 30-year-old Asian man with light skin and clear natural skin texture, a slim oval face with a defined jaw and narrow chin. His expression: neutral and relaxed, a bored office worker at the end of a long day.
He has a lean, average-height build with a relaxed posture.
He has thick straight black hair, medium length, parted in the center with curtain bangs falling to the eyebrows on both sides, ears partly covered, a few loose strands lifting at the crown, natural and a little messy, exactly as in the reference photo.
He wears a plain slim fit white long-sleeve cotton dress shirt, button-front, point collar buttoned to the top, cuffs buttoned at the wrists, tucked in, slightly creased from sitting at a desk. He wears a black tie and black trousers with a black belt and black shoes.
Panels:
- Left column, TOP, FRONTAL HEADSHOT: head and shoulders, front view, both ears visible, nose centered, eyes looking straight into the lens, white collar and black tie knot visible at the neckline.
- Left column, BOTTOM, SIDE PROFILE HEADSHOT: the same head-and-shoulders crop and scale as the top panel, head turned a three-quarter profile view. Neutral expression.
- Center, FULL-BODY FRONT: framed from the neck down, with the head cropped at the base of the neck, standing in a relaxed upright pose, arms hanging naturally at his sides, both hands visible and empty, facing the camera; the tucked white shirt, black tie, belt and black trousers clearly visible.
- Right, FULL-BODY BACK: framed from the neck down at the same crop height, standing straight, facing directly away, showing the plain back of the white shirt tucked into the black trousers, the belt, and the back of the shoes.
Both headshot panels at identical scale with the head at the same height. Both body panels at identical scale. The face appears only in the two left-column headshots; the center and right panels show clothing and body proportions.

Photo Shot on 35mm film, kodak portra.
```

**Step B - face edit on the real photos** (upload the real headshots as @image1, the body sheet as @image2):
```
change the clothing of the photos of the man in @image1 to be the same [white shirt and tie] in @image2. Keep the framing exactly the same for @image1.
```
Result: real face from the photos + costume from the sheet. In the video stage, use the edited headshots for the face and the body sheet for the body.

---

## 3. Props and vehicles

Three steps: explore designs in a grid -> lock one design as a single image -> make an angles grid (exterior + interior) so every shot of it stays consistent.

### 3a. Design exploration grid
```
Generate a set of four real photographs laid out in a 2×2 grid with thin divider lines, 16:9 overall. Each panel shows a DIFFERENT design of [object], photographed as a full-scale, physically built practical [vehicle/prop] on a seamless neutral mid-grey studio backdrop, [camera angle], the whole [object] in frame. Soft, even, flat diffuse lighting; [its own lights as the only colored light]. No people [outside the cockpit], no text, no logos, no numbers.
Every [object]: [shared specs: size, key features, overall attitude].
Top-left — [NAME]: [shape, materials, colours, lights, details].
Top-right — [NAME]: ...
Bottom-left — [NAME]: ...
Bottom-right — [NAME]: ...
All four at the same scale and camera angle so they compare directly. Photorealistic, real practical vehicles, shot on 35mm film, fine grain, realistic [materials] surfaces.
```
(Studio backdrop is fine here; it's a design comparison. Switch to the grey outdoor background for the final.)

Worked example - 4 hostile interceptors:
```
Generate a set of four real photographs laid out in a 2×2 grid with thin divider lines, 16:9 overall. Each panel shows a DIFFERENT design of a hostile single-seat interceptor, photographed as a full-scale, physically built practical vehicle on a seamless neutral mid-grey studio backdrop, front three-quarter view from slightly below, the whole ship in frame. Soft, even, flat diffuse lighting; the ship's own lights as the only colored light. No people outside the cockpit, no text, no logos, no numbers.
Every ship: about 6 meters long, a single narrow tinted canopy with a masked pilot just visible inside, forward-facing guns under the nose, a menacing, cold, mass-produced military look — the opposite of a hand-built rebel ship.
Top-left — THE WRAITH: a flat matte charcoal-black arrowhead dart with faceted stealth surfaces and swept blade wings, thin glowing red neon lines tracing every edge, twin nose guns with red-glowing muzzles, a single red exhaust.
Top-right — THE HORNET: a segmented wasp-like body in glossy black and hazard yellow stripes, a narrow waist, four thin downward-angled wings, a long stinger-like cannon under the tail, two amber eye-like sensor lights at the nose.
Bottom-left — THE MONOLITH DRONE-FIGHTER: a brutal thick wedge of gunmetal-grey armor plating with heavy bolts and no visible wings, held up by four downward hover-thrusters glowing white-blue, a single horizontal slit canopy glowing cold white, two heavy rotary guns on the sides.
Bottom-right — THE BLADE: a needle-thin white ceramic fuselage with a single huge curved crescent wing like a sickle, cold cyan light strips along the wing edge, a mirrored chrome canopy, twin long rail-gun barrels along the nose.
All four at the same scale and camera angle so they compare directly. Photorealistic, real practical vehicles, shot on 35mm film, fine grain, realistic composite, enamel, ceramic and metal surfaces.
```

### 3b. Lock the chosen design (single image)
Describe the chosen design precisely; spell out symmetry and add "No ..." lines for parts the model tends to invent.
```
Real photographs of a hostile single-seat interceptor. Front three-quarter view from slightly above, the whole ship in frame. Plain empty grey barren outdoor background. Soft, even, flat diffuse lighting. No people outside the cockpit, no text, no logos, no numbers. Shot on 35mm film.
A menacing, cold, mass-produced military look. Realistic white ceramic and composite surfaces.
The interceptor has a needle-thin, very long white ceramic fuselage that tapers to a sharp point at the nose and a long pointed spike at the rear. TWO identical huge crescent-moon wings, one on each side, perfectly mirrored and symmetrical: each wing grows out of the rear of the fuselage, sweeps wide outward and then curves forward in a smooth arc, its tip ending in a sharp point level with or past the nose, so together the two wings form a horseshoe or pincer shape that wraps around the fuselage when seen from above. The wings are thin, flat blades with smooth seamless surfaces and only a few fine panel lines. A thin cold cyan light strip glows along the inner curved edge of each crescent wing. A small, low, teardrop-shaped mirrored chrome canopy sits in the middle of the fuselage. Twin long, thin rail-gun barrels run forward along the nose between the two wings, with faint cyan tips.
No tail fin, no vertical stabilizer, no conventional jet wings, no engine pods, no extra guns underneath.
Photorealistic, real vehicle, shot on 35mm film.
```
Hero vehicle example (worn, lived-in):
```
Generate a photographs of a rebel two-seat interceptor, front three-quarter view from slightly below, the whole ship in frame. Soft, even, flat diffuse lighting. Plain empty grey barren outdoor background. No people, no text, no letters, no numbers, no logos.

A sleek, angular, modern fighter design language as a military stealth interceptor with faceted panels, swept wings, a narrow nose, edge light strips. With a larger clear canopy over two seats next to each other. Realistic painted composite, ceramic and metal surfaces, wear and dirt.

It is a worn out ship with some damage visible, but still functional. Repairs and decorations visible.

A flat faceted arrowhead stealth shape like a black military interceptor, but sloppily repainted weathered off-white by hand, with the original black still showing through at scratched edges. A bold hand-painted burnt-orange stripe runs down the spine, and grinning shark teeth are painted on the nose. One wing is a mismatched dark-grey replacement panel held on with visible bolts. Warm amber light strips along every edge, a single glowing orange exhaust. Through the clear canopy: a string of small brass charms and a faded paper photo tucked into the canopy frame.

Photo shot on 35 mm film.
```

### 3c. Angles grid (consistency sheet)
Upload the locked design as @image1. The key: write a **fixed layout** for anything with an interior (where every seat, control and wall is), then describe each panel by what is and is NOT visible from that camera. Without the fixed layout, front and back interior views come out as mirror copies.
```
Generate a 2×2 grid of photographs of the same [object], thin divider lines between panels. Use the attached image as the reference for the [object]. [lighting + background + exclusions]
[Short restatement of the design.]
[Interior] layout, fixed, the same in both interior panels:
- [seats / furniture and their positions]
- FRONT of the [interior]: [what's there]
- [controls: exact position, which side]
- BACK of the [interior]: [different from the front: what's there, and what is NOT there]
- [roof/canopy]
Panels:
- Top-left: [exterior angle A]
- Top-right: [exterior angle B — say what's closest to camera and what is not visible]
- Bottom-left: [interior looking one way — say what is not visible]
- Bottom-right: [interior looking the other way — remember left/right swap when facing back]
Same [object], same scale and lighting in every panel. Photo shot on 35mm film.
```
Worked example - rebel ship angles:
```
Generate a 2×2 grid of photographs of the same rebel two-seat interceptor, thin divider lines between panels. Use the attached image as the reference for the ship. Soft, even, flat diffuse lighting. Plain empty grey barren outdoor background. No people, no text, no letters, no numbers, no logos.
A sleek, angular, modern fighter design language like a military stealth interceptor, with faceted panels, swept wings, a narrow nose and edge light strips. Realistic painted composite, ceramic and metal surfaces, wear and dirt. A worn out ship with some damage visible, but still functional. Repairs and decorations visible.
A flat faceted arrowhead stealth shape like a black military interceptor, but sloppily repainted weathered off-white by hand, with the original black still showing through at scratched edges. A bold hand-painted burnt-orange stripe runs down the spine, and grinning shark teeth are painted on both sides of the nose. One wing has a mismatched dark-grey replacement panel held on with visible bolts. Warm amber light strips along every edge, a single glowing orange exhaust at the tail.
Cockpit layout, fixed, the same in both interior panels:
- Two worn brown leather seats exactly side by side, left and right, facing the nose.
- FRONT of the cockpit (toward the nose): a wide dashboard with amber-lit gauges and switches, the clear windshield sloping down toward the nose, the brass charms and the faded photo hanging from the windshield frame.
- One control stick on the floor between the knees of the LEFT seat. One throttle lever on the left side wall next to the left seat. Nothing else between the seats except a low center console.
- BACK of the cockpit (behind the headrests): a solid curved off-white bulkhead wall, no glass, no dashboard, no gauges; on it a cargo net with a dented metal toolbox and a rolled blanket, a small red fire extinguisher clipped to the wall.
- The canopy glass arches overhead from the windshield back to the top of the bulkhead.
Panels:
- Top-left: front three-quarter view from slightly below, nose pointing toward the camera, the whole ship in frame.
- Top-right: REAR three-quarter view from slightly above, the nose pointing AWAY from the camera, the tail and the glowing orange exhaust nozzle closest to the camera, the orange spine stripe and the back of the canopy visible. The shark teeth are not visible from this angle.
- Bottom-left: cockpit seen from BEHIND the seats, looking forward toward the nose: the backs of both seats and headrests, the dashboard and the windshield ahead, the brass charms and photo hanging in front, the control stick and throttle on the left. The bulkhead is not visible.
- Bottom-right: cockpit seen from the FRONT, from the dashboard looking back toward the tail: the two empty seat cushions and headrests facing the camera, the control stick between the knees of the seat on the RIGHT side of this frame (it is the left seat), the throttle on that same side's wall, and behind the headrests the solid bulkhead with the cargo net, toolbox, blanket and fire extinguisher. The dashboard and windshield are not visible.
Same ship, same scale and lighting in every panel. Photo shot on 35mm film.
```
If the user's first grid fails (interior views look identical, controls move between panels), the fix is always: add or tighten the fixed layout list, and say per panel what must NOT be visible.

---

## 4. Locations (environments)

Visual guidance beats prompts. Ask the user for 1-2 reference images (film stills, photos, a moodboard) for the look they want. Then:
1. **Generate from the reference**, short prompt + "Similar visual style as @image1".
2. **Iterate by editing the result** (upload it as the new reference): change only what you want, and say "keep the overall structure and framing the same".
3. For a set where action happens, describe the **staging**: the hero area, every prop that will matter in the story, what's on/off, and the mood. Leave screens blank if UI will be added later.

City example (two passes):
```
Create a photorealistic cinematic still, a vast abandoned city. No people, no aircraft, no vehicles, no readable text. Similar visual style as @image1. Shot on 35mm film.

Thick mist.
35mm film.
```
```
Add vegetation that covers the building, change the buildings to be more broken down. But keep the overall structure and framing the same.
Add green and grey color tones.
35mm film.
```
Office example (staged set):
```
Create a photorealistic cinematic still a vast empty modern open-plan office at night. A wide three-quarter side view shows one workstation in the foreground and the whole floor behind it. No people, no readable text on any screen, paper or sign. Same visual style as @image1.
In the foreground, a long white bench desk with a single slim black computer monitor on a stand, angled about 30 degrees toward the camera, its screen a plain soft cool-white glow with no interface. In front of it a slim keyboard and black mouse, exactly one red coffee mug, a small loose stack of white paper and a closed manila folder. There is a black mesh office chair, next to the desk.
On the white wall pillar directly behind the desk hangs a large round analog wall clock with a white face, black hour markers, black hands and a thin red second hand, clearly visible and readable as a clock, with no brand or numerals legible.
Behind the workstation, rows of identical white bench desks with empty black mesh chairs and dark monitors stretch deep into the floor. Glass partition walls. Floor-to-ceiling windows along the back wall show a city skyline at night, blurred blue and amber window lights. Half of the long linear ceiling lights are switched off, leaving pools of light and dark across the floor; only the area around the foreground desk is fully lit.
Lonely, quiet, after-hours mood. Shot on 35mm film.
```
