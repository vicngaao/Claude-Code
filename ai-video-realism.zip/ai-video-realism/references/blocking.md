# Shot list + 3D blocking (previz)

Two stages: (1) idea -> shot list, (2) shot list -> 3D blocking animation rendered to MP4. The blocking
clip is attached to the video model as `@video1` ("use @video1 as the previz") so the AI copies its
framing, camera movement, pacing and action, and only adds the realistic look.

## Stage 1 — Shot list

Input: the user's rough idea (a few bullets is enough), the target length, the characters.

Rules (from the tutorial's feedback):
- Keep the story simple and grounded; don't try to be too clever.
- 20-30 s for an intro/short. Most shots 1-3 s; one longer "hero" shot is fine.
- For each shot: number, length, framing + lens, action, dialogue. Short, plain descriptions that can be turned straight into prompts.
- Name the screen direction of anything that travels (e.g. "the ship always flies screen-right").
- Mark anything that will be added later (blank monitor screens for UI).
- Note which shots belong together in one AI generation (same location + characters, 10-15 s per group).

Output as a table, then offer it as a spreadsheet if the user wants one.

Example (the tutorial's "Cubicle" intro):
| # | Len | Shot | Action |
|---|---|---|---|
| S01 | 1.0s | ECU wall clock, 50mm | Second hand ticks. Locked off, slow creep in. |
| S02 | 1.6s | Wide side profile, 35mm | Chin on hand, slumped. Sinks deeper. |
| S03 | 1.0s | Front MCU from behind the monitor, 35mm | Big yawn and stretch. |
| S04 | 2.0s | Over the shoulder, 35mm | Types the prompt, clicks Generate. Screen blank. |
| S05 | 1.6s | Screen insert | UI added later. Calm city in the player. |
| ... | | | |
| C2 | 7.0s | One continuous shot, 30mm | Chase: wide, behind the interceptor, overtake, swoop round the nose into the cockpit, hit, crash to white. |
| S19 | 2.2s | Wide side profile | Asleep on his arms; jolts awake. |
| S20 | 1.8s | Keyboard push-in | Scorch mark between the keys, ember, smoke. |

## Stage 2 — 3D blocking

Ask for (if not already given): the shot list, reference images of characters, vehicles and locations,
which shots to render first. Then write a scene file and render it with the bundled scripts.

### How to work
1. `pip install numpy pillow imageio-ffmpeg` (if missing). No browser, GPU or internet needed.
2. Copy `scripts/example_scene.py` as the starting point. Build each **set once** as a function
   (office, city, cockpit...) and reuse it in every shot so geometry stays identical shot to shot.
3. Write one `Shot(id, dur, title, note, lens, build)` per shot. `build(t)` returns `(nodes, Camera)`.
4. Check framing fast with stills before rendering video:
   `python scripts/render_blocking.py scene.py --shots S02 --still 1.5 --out out`
   Look at the PNG (use the image viewer/Read tool), fix, repeat.
5. Render in groups of 4-5 shots (one AI video generation each):
   `python scripts/render_blocking.py scene.py --shots S01-S04 --name office_open --out out`
   -> `office_open_clean.mp4` (attach as @video1), `office_open_labeled.mp4` (for review), `office_open_timing.txt`.
6. Show the labeled video, ask for notes, iterate. Then give the clean clips + timing sheets.

Speed: ~0.4 s/frame at 960x540 -> a 10 s group renders in ~2 min. Use `--size 640x360` for quick drafts,
`--ss 2` for smoother edges on the final.

### Building blocks (scripts/blocking.py)
- Primitives: `box`, `cylinder` (also cones via `r_top`), `sphere`, `plane`, `polygon_prism` (extrude a top-view outline: wings, hulls), `beam` (glowing laser bolt from A to B), `group`.
- Every `pos/rot/scale/color/visible` can be a number or a function of `t`. `track((t0, v0), (t1, v1), ...)` makes eased keyframes.
- `person(pose, shirt, pants, skin, hair, tie, pos, rot)` = jointed mannequin. Face = -Z. Poses: `stand, sit, sit_type, sit_slump, sit_stretch, sit_rub_eyes, sit_head_down, sit_shock, reach, arms_up`, or a dict of joint angles. Animate with `pose_track((0,'sit_slump'), (1.6,'sit_stretch'), ...)`.
- `Camera(pos, target, lens, roll, flash, fade, fog, bg)` — lens in mm; `flash` (white) and `fade` (black) for transitions; `fog` for city haze; `shake(t, amp)` for hand-held / impact shake.
- `emissive=True` for screens, lights, lasers, exhausts (not shaded).

### Build from the user's reference images
Before modelling any vehicle, set or prop, look at its reference image and match its silhouette: overall shape,
proportions, wing/hull outline, where the canopy/doors/engines are, signature features (e.g. crescent wings that
curve forward past the nose; an arrowhead hull with an engine block at the back). Interiors follow the fixed layout
from the angles-grid prompt (seats side by side, dashboard in front, bulkhead behind, stick between the left
seat's knees). Glass is drawn tinted and solid from outside, and hidden (`visible=False`) once the camera is inside.
`example_scene.py` has `rebel_ship_big()` / `interceptor_big()` as patterns for faceted hulls and curved wings.

### Camera playbook — make action dynamic by default
Users rarely spell out camera moves. For chases, fights or any action beat, propose a choreographed camera
unless they ask for something static. Combine several of these in one shot (a "oner"):
- **Wide establishing chase**: high, behind and to the side, both vehicles in frame, same screen direction.
- **Swing behind the attacker**: the camera slides in behind the pursuer's wing as it fires; the hit lands on the hero.
- **Overtake**: the camera passes the pursuer and closes on the hero from behind; shots hit the scenery ahead (debris).
- **Swoop round the nose**: arc from the side to the front and look back at the cockpit/faces.
- **Push in through the glass**: continue into the interior (hide the glass), close on a face.
- **Impact**: white flash, short hard shake, sparks, a flashing alarm light, the character's head snaps to the side.
- **Over-the-shoulder finale**: swing behind the head, the vehicle rolls/dives, the obstacle fills the frame, cut to black.
Other moves: low-angle hero pass, whip pan to a reveal, dolly zoom on a realisation, a slow creep-in on a
quiet beat, a locked-off frame for comedy. Build camera paths as keyframes in the hero vehicle's own frame
(forward/up/right), so the camera stays glued to the action while it flies (see `c2()` in example_scene.py).
Match the beats to the video prompt's timecodes (Example 5 in references/video.md uses exactly this shot).

### Keep it simple
Blocking only defines framing, positions, timing and motion — the video model adds all the detail. Use smooth,
simple shapes: plain head + hair cap, rounded limbs, basic props. No eyes, noses, fingers, logos, text or other
tiny details. Smooth shading (spheres/cylinders/capsules) and `ss=2` for the final render; boxes only for
genuinely boxy things (desks, monitors, buildings).

### Consistency checklist (from the tutorial's notes — check every render against it)
- Anything that travels keeps the **same screen direction** in every shot, including its entrance.
- Objects sit where they physically would **for each camera angle** (in a side profile of a pilot, the control stick is beside/below her, not in front of the lens). Build the set once and move only the camera.
- Small real-world details: keyboard slopes slightly up toward the monitor, mug/chair/clock stay in the same spot in every shot.
- Interiors: the front and back of a cockpit/room must look different (dashboard in front, bulkhead behind).
- Action reads clearly: in the "Get in!" beat the canopy opens, she turns and looks around, then points/reaches.
- Chases: give the pursuer dynamic moves (diving, banking, closing in) and land at least one hit (sparks, jolt).
- Screens that will get UI later stay a plain blank glow.
- Hero oners: keep camera motion smooth (eased tracks, no sudden jumps); if a shot feels jittery, extend it and smooth the path.

### Notes for the video stage
- Clips can run a bit longer than the edit needs (lead-in and follow-through) — gives the video model leeway.
- Match the prompt's timecoded beats to the timing sheet.
- A single still from the blocking can also be attached as an image to pin one framing ("framed like in @image6").
