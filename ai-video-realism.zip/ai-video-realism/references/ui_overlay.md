# UI on blank monitors (motion-graphics composite)

Video models blur small text, so screens are generated **blank** and the UI is composited afterwards with
`scripts/screen_comp.py`. Goal: it must look filmed — same glow, falloff, tint, reflections and grain as the
blank screen; only the content changes.

Setup: `pip install numpy opencv-python-headless pillow scipy onnxruntime imageio-ffmpeg` (whatever is missing).
The people-matte model is bundled (`assets/modnet_fp16.onnx`), no download needed.

## Example request (from the tutorial)
```
In my demo folder, under generated video clips → UI, there are videos with blank monitor screens and UI recordings to put on them. Composite each UI onto its screen so it looks natural on the monitor: keep the same glow and lighting, so the only thing that changes is what's on the screen.
- Screen 1 (side profile): overlay UI_1.
- Screen 2 (over the shoulder): use UI_2, skipping to the end. Animate me typing the last part of the prompt and clicking Generate. Make the prompt bar and Generate button take up more of the screen so they're readable, without making them huge or cartoony.
- Screen 3 (front view of the screen, then a side profile of me): show the UI player playing UI video 3 in both shots.
- Screen 4: show the UI player playing UI video 4. Keep my reflection on the screen. Her yelling "Get in!" must be clearly heard.
- Screen 5: show the UI player with UI video 5, where she reaches her arm out, then have her real arm come out through the screen. The screen shouldn't go completely white while she reaches.
Keep the UI edges tight to the monitor with no light borders, add a subtle matte texture so the screen feels real, only move the mouse when my hand is on it, play videos at natural speed, and give me the full-length clips.
```
Worked code for three of these screens:
```python
from screen_comp import *
# Screen 1: screen recording on a side-view monitor
composite_video('screen_1.mp4', track_screen('screen_1.mp4'), VideoUI('UI_1.mp4'), 'screen_1_UI.mp4')
# Screen 4: a clip playing in the app's player, reflection kept, clip audio mixed in
ui = PlayerUI('UI_player.png', 'UI_video_4.mp4', rect=(175, 418, 1424, 1120), crop=(0, 0, 2323, 1307))
composite_video('screen_4.mp4', track_screen('screen_4.mp4'), ui, 'screen_4_UI.mp4', reflection=2.2,
                extra_audio=['UI_video_4.mp4'],
                filter_complex='[1:a]volume=0.55[p];[2:a]highpass=f=90,volume=1.15[u];[p][u]amix=inputs=2:normalize=0:duration=first[a]')
# Screen 2: over the shoulder, his head stays in front of the UI
composite_video('screen_2.mp4', track_screen('screen_2.mp4', occluder=lambda f: person_matte(f), hidden='left'), my_ui_animation, 'screen_2_UI.mp4',
                occluder=lambda i, f: person_matte(f))
```

## 1. Inventory
The user uploads (or names) a folder with:
- plates: AI videos with blank screens (`screen_1.mp4` ...)
- UI sources: screen recordings, app screenshots, a player screenshot + the clips that play in it
- a description of which UI goes on which screen and what should happen (typing, clicking, a video playing...)

Ask only for what's missing. Make a pairing table (plate -> UI -> notes) and confirm it in one line.

## 2. Find the screen in every plate
```python
from screen_comp import *
probe('screen_3.mp4')                         # fps, size, frames, duration, hard cuts
preview_detect('screen_3.mp4', 'chk.png', frame=30)   # then LOOK at chk.png
```
- Auto-detect picks the biggest, brightest, most rectangular glowing area. If it picks the wrong thing, pass
  `seed=(x, y)` (a point inside the screen).
- Plates with hard cuts (front view -> side view) are split automatically; check one frame from each part.
- Choose a tracking method:
  - `track_screen(v)` — default, re-detects the screen each frame (camera moves, screen mostly visible).
  - `track_screen(v, static=True)` — locked-off camera: one stable quad (best quality).
  - `track_screen(v, occluder=lambda f: person_matte(f), hidden='left')` — over-the-shoulder: the head covers one
    side of the screen. The covered corners are rebuilt from the visible edge (one rigid shape for the whole shot),
    so the UI stays locked to the monitor instead of following the outline of the head. Use `hidden='right'` if
    the head covers the right side; adjust `ratio` (default 1.6) if the rebuilt width looks too narrow/wide.
  - Tracks are fitted to smooth curves and frames where detection jumps are dropped, so the UI never jitters,
    warps or rotates. Check `preview_detect` on the first, middle and last frame before compositing.
  - Short segments after a hard cut at the very end of a plate (another shot) are skipped automatically
    (`min_segment=8`), so no UI lands on the wrong shot. Check `probe(v)['cuts']`.
- Partial screens (extreme close-up of a corner): build the quad from the visible edges, assume a 16:9 screen
  that extends off-frame, and add a horizontal vanishing point so lines higher up the screen flatten out (a
  parallelogram looks "tilted down"). Size it so the important UI element sits fully in frame.

## 3. Build the UI for each screen
- `VideoUI('UI_1.mp4', time_map=..., patches=[...])` — a screen recording. `time_map(t)` maps plate time to UI
  time: hold a still frame while the actor isn't touching the mouse, advance only while the hand is on it
  (look at a contact sheet of the plate to find those frames). Use `patches` to paint over private info
  (credit balance, emails).
- `ImageUI('screenshot.png')` — static screen.
- `PlayerUI('player.png', 'clip.mp4', rect=(x0, y0, x1, y1), crop=..., paused=False)` — a video playing inside an
  app's player. `rect` = video area in the screenshot; `crop` trims browser chrome to 16:9. Plays at natural
  speed; if the clip is shorter than the plate it holds its last frame (or set `paused=True` for a still).
- A custom function `ui(i, t) -> BGR image` for animated UI (typing a prompt, cursor moving to a button, hover,
  click, "Generating..." spinner). Draw it with Pillow at 1920x1080 using real crops of the app's own icons
  (paste crops from the user's screenshots, background-matched and feathered) so it matches the real UI.
  Keep buttons readable but not cartoonish. When the actor's head covers part of the screen, lay the UI out
  so the important part (prompt, Generate button) is in the visible area.
- Save each custom UI animation as its own MP4 too — the user can reuse it.

## 4. Composite (always the full-length plate)
```python
composite_video('screen_4.mp4', quads, ui, 'screen_4_UI.mp4',
                reflection=2.2,                          # keep the actor's reflection on the glass
                occluder=lambda i, f: person_matte(f),   # people/arms in front of the screen
                extra_audio=['UI_video_4.mp4'],
                filter_complex='[1:a]volume=0.55[p];[2:a]highpass=f=90,volume=1.15[u];[p][u]amix=inputs=2:normalize=0:duration=first[a]')
```
What it does automatically: fits the blank screen's own lighting (glow, falloff, tint), snaps the UI edges to
the real display/bezel boundary (no light rim), adds a matte LCD texture (veil glow, slightly raised blacks
and lower contrast at angles, backlight mottling, fine grain), keeps only the plate's sensor noise (not the
old blank-screen content), and swaps the screen's glow on the surroundings for one matching the new content.

Options worth knowing: `edge_pad` (px the UI tucks under the bezel, default 3: raise if a thin coloured line
remains, lower if a bright band spills onto the bezel), `texture=False`, `grain` (lower if it looks noisy — e.g. 0.006 for close-ups),
`mottle`, `veil`, `soft` (more blur to match a soft plate), `dof` (0..1 map: sharp around the key UI element,
blurrier toward the frame edges, for shallow-focus close-ups), `white_from=[frames]` (one fixed lighting model
for screens that wake up/flash), `post(i, img, plate, alpha)` for per-shot effects.

Arms reaching out of a screen: combine `person_matte` with `difference_matte(frame, clean_ref, screen_mask)`
(clean_ref = a frame before the arm appears). If the monitor shakes violently when something bursts through,
don't try to track it: dissolve the UI into the plate's own effect with `post` (e.g. blend to the plate over
~7 frames as the burst starts).

## 5. Audio
- Keep the plate's audio by default.
- A player showing a generated clip: mix that clip's audio in, under the plate (highpass ~90-150 Hz so it sounds
  like it's coming out of speakers). Make dialogue that matters clearly audible.
- Remove stray music/stingers from UI clips (analyse the audio; mute those seconds or leave the clip's audio out).
- Clicks: add a short mouse click (press + release ~85 ms apart) exactly when the button visually presses.
  Generate it with numpy (filtered noise transient + tiny resonance), no download needed.

## 6. Review before delivering (look at the frames!)
- `contact_sheet(out, 'sheet.png')`, then zoom into each screen edge and any occluder boundary.
- Checklist (from real feedback):
  - no light bar/blue rim between UI and bezel; edges tight
  - UI is locked to the monitor: no warping, sliding or rotating; nothing composited on a different shot after a cut
  - UI looks like part of the screen (matte texture, not pasted on); not too grainy
  - mouse/typing only moves while the actor's hand is on the mouse/keyboard
  - videos play at natural speed (never slowed/ramped to fit); hold a frame instead
  - people/arms stay in front of the UI; no UI or glow drawn over shoulders
  - reflections preserved where the plate had them
  - perspective matches the monitor (no tilt), important buttons fully in frame
- Deliver **full-length** clips (the whole original shot with the UI embedded), never trimmed portions — the
  user trims in their editor. Keep the plate's frame rate.

Speed: only the area around the screen is processed, so small/side-view screens take ~0.3 s per 1080p frame and
full-frame screens ~1.5 s (a 4 s plate: 1-4 minutes; people-matting adds ~0.6 s/frame). Render one plate at a time.
