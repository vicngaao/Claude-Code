# AI video prompts (Seedance 2.5 in OpenArt)

Turn the assets + the shot list (+ optional 3D blocking clip) into image/video-to-video prompts.

## Tool settings (OpenArt)
- Model: **Seedance 2.5**. Upload references under "Add visual references" — images become `@image1, @image2...`, a video becomes `@video1`, numbered in upload order.
- Audio: **On**. Auto Polish: **Off** (it rewrites your prompt).
- Output: 16:9, length = the end time of the last beat (keep each generation **10–15 s**, max ~22 s; longer clips drift and lose consistency).
- Run a **Draft** (lower resolution) first to check the prompt, then render the keeper at **1080p**.
- Split the shot list into groups of shots that share a location and characters; one prompt per group.

## Prompt structure (always in this order)
1. **Opening line** — "Generate a realistic video of [who/what] [where]. [mood in a few plain words]."
2. **Previz line** (when a 3D blocking clip is attached as @video1) —
   "Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1."
   Add "Single continuous shot, no cuts." if the blocking is a oner.
3. **Reference map** — say what every reference is for:
   "Use @image2 as a reference for the man's face and @image3 as reference for the man's body. Use @image1 as the office scene."
   For multi-element scenes use labelled lines: `Setting: ... @image5.` / `Ships: ... @image1.` / `Characters: ... @image2.`
4. **Timecoded beats** — one line per shot: `0-3s: Cut to a [shot type] of [subject + @tag] [action]. [lock]`
   - Start every beat with the shot type (close up, side profile, front view, over the shoulder, framed from behind...).
   - Re-tag the character in each beat they appear in.
   - Dialogue in quotes: yells "hurry and get in".
   - Beats must line up with the blocking clip's timing when one is attached (use tenths of a second if needed).
5. **Locks** — things the model must not change or add: "Keep the monitor screen blank." "NO lamp at the desk."
6. **Audio** — "No Music." then "Sounds: [specific diegetic sounds]". Music is added in the edit.

Style: short literal sentences, same tone as the asset prompts. No camera-jargon soup, no adjectives stacked for "cinematic".

### Handy tricks
- **Frame reference**: a still from the 3D blocking can be attached as an image and pointed to: "Cut to a shot framed from behind the cockpit seats like in @image6."
- **Colour swatch**: attach a flat colour image to pin an effect's colour: "teal colored @image7 laser bolts".
- **Blank screens**: if UI will be added later with motion graphics, always lock screens blank — video models blur small text.
- **Ships/vehicles**: name the direction of travel consistently with the blocking.

## Template
```
Generate a realistic video of [subject] [location]. [Mood].

Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1.

Use @image[face] as a reference for the [character]'s face and @image[body] as reference for the [character]'s body. Use @image[set] as the [location].

0-[t]s: [Shot type] of [subject @tag] [action]. [lock]
[t]-[t]s: Cut to [shot type] ...
...

No Music.
Sounds: [sounds].
```

---

## Worked examples (from the tutorial)

References used across the office scenes: @video1 = 3D blocking clip, @image1 = office set, @image2 = man's face (edited real headshots), @image3 = man's body sheet. Previz line added (recommended; the originals attached the blocking without naming it).

### Example 1 — Intro scene (11 s)
```
Generate a realistic video of a man working inside his office at night. He is bored, tired, sleepy, and weary.

Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1.

Use @image2 as a reference for the man's face and @image3 as reference for the man's body. Use @image1 as the office scene.

0-2s: Start with a close up shot of the clock ticking on the wall.
2-6s: Cut to a side profile shot of the man @image2 sitting at his desk. He is sleepy and tired. he leans his head against his arm. He suddenly reaches his arms up to yawn. Keep the computer monitor screen blank.
6-8s: Cut to a front view of the man @image2, looking into the monitor at his desk. Tired and weary.
8-11s: Over the shoulder shot behind the chair of the man. The man looks into the monitor screen. Keep the monitor screen blank.

No Music.
Sounds: Subtle ticking of the clock on the wall, sounds of the man typing into his computer. Sounds of the tired man working at his desk.
```
Settings: Seedance 2.5, Audio on, 16:9, 1080p, 11s.

### Example 2 — Long office scene (22 s)
Extra refs: @image4 = pilot character sheet, @image5 = over-the-shoulder still.
```
Generate a realistic video of a man working inside his office at night. He is bored, tired, sleepy, and weary.

Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1.

Use @image2 as a reference for the man's face and @image3 as reference for the man's body. Use @image1 as the office scene.

0-3s: Cut to a close up shot of the computer monitor screen. Keep the monitor screen blank.
3-6s: Cut to a front view of the man @image2, looking into the monitor at his desk. He's tired and watching the monitor, he takes a breath and tries to relax. He is typing and working at his desk.
6-10s: Cut back to a close up shot of the computer monitor screen. Keep the monitor screen blank.
11-14s: Cut to a front view of the man @image2, looking into the monitor at his desk. he leans in rubbing his eyes, confused and whispers "what the...?"
17-20s: Cut to a side profile shot of the man @image2 sitting at his desk. Still leaning in and confused.
20-22s: A flash of light transitions to a warp light tunnel. No people visible, camera only speeds through the warp tunnel.

No Music.
```
Settings: 16:9, 1080p, 22s. (Note for users: keep beats continuous with no gaps — 10-11s and 14-17s are unassigned here; the model fills gaps unpredictably.)

### Example 3 — Sudden wake up (9 s)
```
Generate a realistic video of a man working inside his office at night. He is asleep at his desk and suddenly awakes from a bad dream.

Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1.

Use @image2 as a reference for the man's face and @image3 as reference for the man's body. Use @image1 as the office scene. NO lamp at the desk.

0-3s: Cut to a side profile shot of the man @image2 sleeping at his desk. He suddenly wakes and jerks backwards in shock.
3-6s: close up front view of the man clutching his chest, breathing quickly and heavily. He looks down towards the direction of where his keyboard is.
6-9s: close up shot on the man's keyboard. There is a burnt hole in the keyboard that is smoking. A few subtle embers around the hole.

No Music.
Sounds: Subtle burning sounds from the smoking keyboard.
```
Settings: 16:9, 1080p, 9s.

### Example 4 — "Get in" (13 s, no blocking video; blocking still as a frame reference)
References: @image1 = rebel ship angles grid, @image2 = pilot sheet, @image3 = man's face, @image4 = man's body, @image5 = city, @image6 = blocking still (behind the seats), @image7 = teal colour swatch.
```
Generate a realistic video of an aircraft flying through a city landscape @image5. a misty, overgrown city of tall towers ruins @image5.

Setting: a misty, overgrown city of tall towers ruins @image5.
Ships: a weathered two-seat fighter @image1.
Characters : And a young woman pilot in a red jacket @image2 seated inside the cockpit of the two seat fighter @image1.
A male office worker. Use @image3 as reference for the man's face and @image4 as reference for the man's body.

0-3s A view casually flying though a city landscape. No aircraft is visible.
3-6s Side profile of a two seat fighter flies into the frame inside the city landscape. A female pilot @image2 in the cockpit.
6-9s Cut to a close up side profile shot on front of the aircraft flying inside the city landscape. The canopy lifts up, the female pilot @image2 looks directly at the camera and yells "hurry and get in".
9-13s Cut to a shot framed from behind the cockpit seats like in @image6. The female pilot is in the left cockpit seat flying the aircraft. The canopy is lifted up. The man @image3 @image4 falls in from above into the right side pilot seat. The canopy closes from above them. teal colored @image7 laser bolts fly past them as they speed through the city landscape.

No Music.
Sounds: subtle wind, sound of the aircraft flying, the canopy lifting
```
Settings: 16:9, 1080p, 13s.

### Example 5 — Chase scene (8 s, one continuous shot driven by the 3D blocking)
Prompt-only attempts at this shot failed (the model couldn't follow the camera path). Blocking as previz fixed it.
References: @video1 = 3D blocking oner, @image1 = crescent interceptor, @image2 = rebel ship angles grid, @image3 = pilot sheet, @image4 = man's face, @image5 = city.
```
Generate a realistic video of an aircraft chase scene through a city landscape. Use @video1 as the previz and it defines the pacing, camera angles, camera movement, and framing. Map the realistic textures onto @video1.
Single continuous shot, no cuts.

Setting: a misty, overgrown city of tall towers ruins @image5.
Ships: a weathered two-seat fighter @image2 chased by a white interceptor with curved crescent wings and cyan lights @image1.

Inside the two-seat fighter @image2: a man in a white shirt and black tie on the right @image4. And a young woman pilot in a red jacket @image3 seated next to the man.

0.0-1.9s Both ships race through the city, the fighter @image2 trying to escape while the interceptor chases it down @image1.
1.9-2.7s The camera swings in behind the interceptor's @image1 wing. It fires cyan laser bolts. One laser clips the fighter's wing @image2 — sparks fly and the fighter jolts. A streak of flames and sparks erupts from the fighters wing.
2.7-3.9s The camera overtakes the interceptor and closes in on the fighter from behind, bolts streaking past. Laser bolts flying past the fighter, hitting the building in front, crumbling parts of the building in dust and debris.
3.9-5.4s The camera swoops around the fighter's nose. We see the man @image4 through the glass canopy, and the camera pushes in through the canopy.
5.4-6.3 Inside the cockpit, close on the man's face. He is terrified, gripping his seat. He yells "Mayday!".
A direct hit. White flash, sparks burst from the console, a red alarm light starts flashing.
The man @image4 snaps his head toward the side window. The camera swings around behind his head.
6.3-6.8s Over the shoulder shot behind the man in the cockpit: the fighter rolls and dives. The fighter crashes towards a building wall. He throws his arms up. The sound of a loud collision as the screen goes black.

No Music.
Sounds: laser bolts, aircraft engines, alarms going off when the fighter gets hit
```
Settings: 16:9, 1080p, 8s.
