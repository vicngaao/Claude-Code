---
name: lead-generation
description: >-
  Walk the user through the full AI Fire lead generation framework (scrape, pre-qualify, enrich and
  research, personalize), execute one complete run with them, and then save that successful run as a
  new named skill so the process becomes repeatable. Use this skill whenever the user wants to
  "find leads", "build a lead list", "set up lead generation", "create a lead gen skill",
  "generate leads for [ICP]", "scrape prospects", "build an outbound list", "/lead-gen", or
  describes who they sell to and wants a contactable, qualified, upload-ready list back. Trigger it
  even when the user does not name a tool or a source, as long as they want leads that match a
  profile, and especially when they want a repeatable pipeline rather than a one-off list. The end
  product is two things: an upload-ready lead list, and a new skill that rebuilds that list on demand.
---

# Lead Generation

This skill has one purpose: turn a lead generation use case into a repeatable machine. It does that in three acts. First it interviews the user until the whole picture is locked. Then it executes one complete run with them: scrape, pre-qualify, enrich and research, personalize, deliver. Then, once the user approves the result, it writes a **new skill** for that exact use case, so the next run is one command instead of one conversation.

A lead list is only as good as the worst decision in it, and most bad decisions happen before any tool runs. That is why the interview comes first and is thorough. Everything downstream (which scraper, which filters, which enrichment provider, which research, which columns) is derived from the answers, so a gap in the interview becomes a gap in every future run of the generated skill.

## The flow

```
0. Interview        lock the full picture before anything runs
1. Plan             write the run plan, estimate cost, confirm
2. Scrape           route to the source, test batch, full pull       -> references/source-routing.md
3. Pre-qualify      script first, research subagents only if needed  -> checkpoint: user reviews list
4. Enrich+research  contact data per cadence, research per           -> references/enrichment.md
                    personalization goals, hygiene gate                 references/hygiene-gate.md
5. Deliver          upload-ready, color-graded list with variable    -> checkpoint: user approves run
                    columns
6. Offer the skill  ask first, then build it with the skill-creator  -> references/skill-generation.md
                    skill
```

Steps 2 and 3 run continuously without stopping. The two checkpoints are deliberate: enrichment spends money per row, so the user verifies the qualified list before it is enriched, and the generated skill freezes the configuration, so the user approves the run before it is frozen.

Read each referenced file when you reach that phase. This file is the map; the references hold actor IDs, schemas, recovery patterns, and templates.

## Two operating modes

- **Vault mode.** A `Context/icp.md`, `Context/offer.md`, or `Context/config.md` exists in or above the working directory. Read those as ground truth and confirm instead of interviewing from zero. Log the run to the active profile's daily note. Never use em dashes.
- **Standalone mode.** No context docs present. Interview fully. Deliver the list, the run summary, and the generated skill.

If unsure, ask once.

## Phase 0: The interview

This is the most important phase, and it is a real back-and-forth, not a form. Do not start scraping until every block below is answered, played back, and confirmed. Go as deep as the answers require: a vague answer gets a follow-up question, not a guess. Ask one block at a time, react to what comes back, and probe until each answer is concrete enough to become a filter, a rule, or a column. An hour of interview is cheaper than one wrong scrape.

Existing documents are a starting point, never a substitute. When an ICP or offer doc exists, summarize it back and confirm it is exactly right for this run. When no documents exist (the common case outside the vault), the interview carries everything, so run it even more thoroughly.

**1. Offer and ICP.**
- What is being sold, and why would these leads care.
- Company-level ICP: industry, size band, geography, hard disqualifiers.
- If an ICP doc already exists (`Context/icp.md` or similar), read it, summarize it back in two lines, and ask: "Is this exactly who we are hunting for this run?" Only re-interview the parts they change.
- **If they have no ICP, build one with them before anything else.** Ask: who are your best current customers, and what do they have in common? Who gets the most value fastest? Who pays without friction? Which segment do you most want more of? From the answers, propose one or two candidate ICPs in plain terms (industry, size, geography, buyer role) and iterate until they pick one. A run cannot target "anyone who might buy"; lock a single ICP per run and note the second candidate for a later run.

**2. Where the ICP lives, and what scrapes it.**
Recommend, do not just ask. The product plus the ICP usually decides this:
- Local businesses (an AI-services shop selling to gyms, dentists, restaurants) live on **Google Maps**.
- SaaS companies and B2B roles live on **LinkedIn, Sales Navigator, or a lead database** (Vibe Prospecting, Apollo), or in **Google search results and aggregators** depending on size.
- Influencers and creators live on **social media** (Instagram, YouTube, TikTok).
- Niche communities live in **directories, marketplaces, Reddit, forums**.

Then name the tool and its fallback for the chosen source:
- LinkedIn and social media: **Apify** actors (fallback: Firecrawl over public pages).
- YouTube: **vidIQ** connector or Apify YouTube actors.
- Reddit: **Apify** Reddit actors, or a Reddit MCP if one is connected.
- Google results, aggregators, directories: **Firecrawl** schema-driven scrape (fallback: WebSearch + WebFetch, slower and coarser).
- Broad firmographic matching: **Vibe Prospecting** or Apollo.

The full decision tree with actor IDs is in `references/source-routing.md`. Read it before recommending.

End this block by locking the exact, named source, never just the platform category: "the CB Insights unicorn list at this URL", not "a directory". The source (where the data lives) and the tool (what reads it, e.g. Firecrawl) are two separate locked decisions, and the user must be able to open the source link and inspect it themselves.

**3. Pre-qualification criteria.**
- What are the concrete, testable rules a lead must pass?
- How exactly would they qualify one by hand? Walk the logic once.
- Who is a **golden lead**, the one they would drop everything to call?

Split the criteria into two piles as they answer, because the piles run differently in Phase 3:
- **Scriptable** (headcount, geography, industry label, funding date, rating count): a Python filter handles these, free and instant. Most criteria, usually 70 to 80 percent of the filtering, land here.
- **Research-based** ("actually sells POS software to gyms", "runs paid ads", "has a sales team"): only a visit to their website or profile can answer these. These cost subagent time, so keep the pile small and sharp.

**4. Who to talk to, and the cadence.**
- Exact titles and seniority of the person they want (CEO, sales director, head of growth).
- Where that person is reachable: email, LinkedIn, WhatsApp, phone, communities.
- What the outreach cadence is. This decides the data points to find: email-only needs a verified email (plus LinkedIn for research); a multi-touch cadence across email, LinkedIn, WhatsApp, and calling needs all four contact points, which multiplies enrichment cost. Say that out loud.

**5. Personalization.**
Read `references/personalization.md` first, then run its interview: show the levels (first name, job title, LinkedIn post, competitor name drop, case study, secondary decision maker), ask which they want per touch, and collect the actual templates. This skill does variable-based personalization: the user writes the copy, the pipeline fills only the variables. The templates define the variable columns of the final list, and the chosen personalization defines what Phase 4 researches. A cadence can carry different personalization per step (email 1 vs WhatsApp 1); collect all of it.

**6. Tool access audit.**
Check what is actually connected before promising anything:
- **Enrichment**: AnyMailFinder, Prospeo, Apollo. If none is connected, recommend a subscription plainly: without a real finder-verifier, email verification rates are too low to protect sender reputation. Let them decide; a run can proceed without enrichment, but say what it will lack.
- **Research**: Firecrawl. Fallback is WebFetch and WebSearch, workable but slower and less structured.
- **Delivery**: Google Workspace (`gws` CLI or connector) for a Google Sheet, otherwise CSV.
- The per-tool checks live in `references/connectors.md`; the substitution ladders in `references/fallbacks.md`.
- Close this block by **locking one named tool per data point**: this finder for email, this one for phone, this one for research, this delivery target. "Whatever is available" is not a locked answer. If the preferred tool is missing, the user picks the substitute now, in the interview, not the run later on its own.

**7. Volume.** Target lead count. Sourcing over-pulls to survive qualification (`references/volume-and-batching.md` has the math).

**Close the interview with a full playback.** Restate every locked answer in one screen: offer, ICP, source, criteria (both piles), golden lead, titles, cadence, contact points, personalization variables, templates, tools available, volume, delivery format. Ask for one final confirm. If any answer is still vague ("mid-size companies", "somewhere in tech"), it is not locked; go back and sharpen it. Nothing downstream can be more precise than this playback.

## Phase 1: The plan

Write the plan down before spending a credit and present it **as tables**. Concise, one screen, four tables plus a closing line.

**Table 1, the source.**

| Item | Decision |
| --- | --- |
| Lead source (linked) | the actual site or database, e.g. the CB Insights unicorn list, with its URL |
| Scrape tool | e.g. Firecrawl schema scrape |
| Method | e.g. Google search to find the index, then paginate 5 listing pages |
| Expected records and cost | numbers, not adjectives |

**Table 2, qualification.** One row per criterion: the rule, its pile (script or research), and exactly how it gets checked.

**Table 3, enrichment.** One line stating the purpose (what we are trying to find and why), then one row per data point: data point, locked tool, agreed fallback.

**Table 4, research and personalization.** One row per variable: variable, research recipe, fallback value.

Close with delivery format, target volume, and total estimated cost.

**The plan is a contract.** Nothing runs until the user approves it. After approval, every deviation stops the run and asks first: a different source, a different tool, fewer pages to save credits, any fallback. Present the change, the reason, and the cost difference, then wait for a yes. Swapping the named source for a cheaper one (Wikipedia instead of the named directory) without asking is exactly the failure this rule exists to prevent. The plan is also the skeleton of the generated skill in Phase 6, so precision here pays twice.

## Phase 2: Scrape

- **Map the ICP to the source's real filters** (industry enums, size bands, locations, titles, keywords). Show the mapping before a large run.
- **Test batch first**, about 50 records. Measure the pass-rate against the scriptable criteria, then size the full pull: `raw_needed = ceil(target / pass_rate * 1.1)`.
- **Scrape the source the plan named.** State the URL(s) being read as you read them. Cutting coverage to save credits, or reading a cheaper mirror of the named source, is a plan deviation: stop and ask first.
- **Persist immediately.** Raw results go to disk the moment they land. Conversation memory is not storage.
- Apify discipline (two-step `call-actor`, expect the ~30s timeout, recover via `runId`) is in `references/source-routing.md` section 9. Follow it for every actor call.

## Phase 3: Pre-qualify

**Script first, always.** Run the scriptable criteria as a Python filter over the raw file. This is free, instant, and reproducible, and it usually removes most of the noise before anything costs money.

**Research-based criteria run through subagents**, batched 10 leads each, all spawned in one message so they run in parallel. Each subagent visits the lead's website and checks: do they actually do the thing? Qualified or disqualified, with a reason and a confidence.

**When research-based qualification runs, it doubles as research.** The subagent is already on the website, so it gathers everything Phase 4 would otherwise revisit: what the company does, the casual/normalized company name and common abbreviations, case studies and named clients, services, positioning. One visit, two jobs. Store it all as columns.

If the `sales:lead-qualifier` agent type is unavailable, spawn `general-purpose` subagents with the same instructions.

> **Checkpoint.** Present the qualified list to the user: counts in and out, the pass rate, and five example rows. Ask them to spot-check and say when they are ready. Do not start enrichment until they confirm, because enrichment is the first step that spends money per row.

## Phase 4: Enrich and research

Everything here is driven by two earlier answers: the **cadence** decides which contact points to find, and the **personalization** decides what to research.

**Contact data.** Read `references/enrichment.md`. The essentials:
- Email via AnyMailFinder (name + company domain) or Prospeo (which also resolves an email straight from a LinkedIn URL). Phone and WhatsApp via Prospeo or Apollo, only when the cadence uses them.
- **Verify, then gate.** Only verified emails move forward. Then run the hygiene gate (`references/hygiene-gate.md`): thirteen flags, computed by script, zero flags to pass.
- **Partial-data leads.** When a lead has some but not all required contact points (email found, WhatsApp missing), do not decide for the user. Report the split and ask: drop them, or keep them and skip the missing channel in the cadence?

**Research for personalization.** Read `references/personalization.md` for the research recipe per level. The rule: research exactly what the variables need, nothing more. A competitor name drop needs competitor research; a secondary decision maker needs a people lookup on the company; a LinkedIn-post hook needs the person's recent posts. Batch 5 leads per `sales:lead-researcher` subagent, all spawned in one message.

Run the accuracy pass from `references/personalization-accuracy.md` over the finished claims: re-derive every claim from the raw source, never from the pipeline's own output.

## Phase 5: Deliver

The output is an **upload-ready lead list**: the user should be able to upload it to Instantly or Smartlead and start the campaign with no further edits.

- Columns: identity, company, every contact point the cadence needs, qualification verdict and reason, and **one column per personalization variable** (First Name, Casual Company Name, Secondary Decision Maker, Competitor Name, whatever the templates defined).
- Google Sheet via `gws` when available and wanted, CSV always. Keep a JSON copy.
- **Format the Sheet so list health is visible at a glance.** A wall of white cells hides the story. The house look, applied in one `spreadsheets batchUpdate`:
  - **Score and Tier columns.** Compute a 0-100 `Score` per row from the data the run produced (verified email carries the most weight, then personalization depth, then signal strength like competitor closeness or engagement type, then hygiene). `Tier` shows it as an icon: 🟢 A, 🟡 B, 🟠 C. **Sort the rows by Score, best first.** Document the score weights in the sheet or the run record so they are not a mystery.
  - Dark bold frozen header with a filter; freeze the identity columns; **hide gridlines**; subtle alternating row banding; green tab color.
  - Color grade the judgment columns: email status green/amber/red, personalization level blue vs soft amber, competitor closeness green/amber/orange, Score on a red-yellow-green gradient, quality scores white-to-green.
  - Blank cells in columns the cadence needs turn red; rows that failed qualification or hygiene grey out entirely.
  - A CSV cannot carry any of this, so it gets the `Score` and `Tier` columns and the sort.
  - **Email Preview column.** After the variables are filled, render the complete email (template with every variable embedded) into an `Email Preview` column per row. It is the last column added and the fastest way to judge the list: read five previews and you know if the campaign is ready.
  The user should learn the list's health by scrolling, not by reading every cell.
- Final report: counts at each stage, pass rate, hygiene survival fraction, find-rate and verify-rate, cost if known, one line per fallback used. Close the report with the sentence that marks a finished run: **"This lead list is now ready to be uploaded to Instantly."**

> **Checkpoint.** Ask the user to review the list and confirm the run was a success. The generated skill will freeze this exact configuration, so only a run the user is happy with gets frozen.

## Phase 6: Offer to save the run as a skill

This is the payoff, but it is an offer, never an automatic step. Ask the user: "Want me to save this run as a reusable skill, so next time it is one command?" Build only on a yes; a user testing a one-off list does not want their skills folder growing on its own.

On a yes, **invoke the `skill-creator` skill and build the new skill through it**, so the result complies with Anthropic's skill-writing standards by construction. Read `references/skill-generation.md` alongside it: that file is the content spec for what gets frozen. In short:

- Write a new skill at `~/.claude/skills/<use-case-slug>/SKILL.md` named after the use case (`fintech-unicorns`, `saas-sales-hiring`), never a generic name.
- The generated skill freezes everything this run decided: source, exact actor and filters, both piles of qualification criteria, enrichment providers per data point, research recipe, variable columns, templates, delivery format. It asks only for what genuinely changes between runs (volume, geography, date cutoffs).
- It follows the same pipeline shape as this skill (scrape, pre-qualify with checkpoint, enrich and research, deliver upload-ready) and carries the operating rules below verbatim where relevant.
- Validate it (the skill-creator's `quick_validate` script if available, otherwise check frontmatter and structure by hand), then tell the user its name and how to invoke it.

An existing example of a generated skill is `linkedin-post-engagers`: one warm use case, frozen end to end.

## Operating rules that always apply

These rules apply to this skill and get copied into every skill it generates, because they are how runs stay cheap, honest, and reproducible.

- **Narrate the framework as you run it.** When a phase completes, post a short summary table in chat (what came in, what survived, what it cost) and name the step you are starting, so the run itself teaches the scrape, pre-qualify, enrich and research, personalize sequence.
- **Parallelism.** Every subagent in a phase is spawned in one message.
- **Persist to disk immediately.** Sourced data, subagent outputs, merges: written as produced.
- **Script before subagent.** Anything a filter can compute never goes to an agent.
- **Never trust the source.** Scraped fields are a starting point, verified against live research.
- **Apify discipline.** Two-step `call-actor`, expect the ~30s timeout, recover via `runId`, sample 2 to 3 items before full download.
- **Cost awareness.** State rough cost before any large paid pull. Dedup before paid enrichment.
- **Only verified emails move forward.** Unverified addresses wreck sender reputation.
- **Every fallback is approved before it runs.** A failing tool or a ballooning cost stops the run: present the change, the reason, and the cost difference, then wait for a yes. The approved substitution still gets its one line in the final report. Silently substituting and reporting success is the one unforgivable move.
- **Never invent a count.** Counts come from a script over a file on disk.
- **Verify against the source, not your own output.** A QA pass over the file that produced the copy always agrees with itself.
- **Dedupe against every list already sent**, on id, email, phone, and normalized name.
- **Read the assembled copy as prose.** Correct data can still be broken English.
- **No em dashes**, ever, in anything written.

## Hand-offs

Sending, warmup, SPF/DKIM/DMARC, and campaign management belong to the `outreach` skill and the sending platform. This skill ends at the upload-ready list and the generated skill.
