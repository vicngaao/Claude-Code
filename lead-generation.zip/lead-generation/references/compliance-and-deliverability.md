# Compliance and deliverability

A lead list is a pile of personal data about real people, and it is about to be pointed at a sending domain the business cannot easily replace. Both facts have to be handled inside the list build, not left to whoever sends the campaign. This file is operational guidance, not legal advice. When the answer decides whether a campaign is legal, tell the operator to check with their own counsel.

## What the list itself has to carry

Add these columns during enrichment. They cost nothing and they are impossible to reconstruct later.

| Column | Why |
| --- | --- |
| `source` | Which actor, database or directory the row came from |
| `sourced_at` | The date the row was pulled. Personal data goes stale, and staleness is the cause of most bad rows |
| `person_country` | Drives which regime applies |
| `lawful_basis_note` | One short line: why contacting this person about this offer is defensible |
| `verified_at` | When the address was verified, and by what |

A row that cannot say where it came from cannot be defended and cannot be debugged. Treat a missing `source` as a hygiene failure.

## Geography changes the rules, so split the list by geography

Do not build one list and hope. Split on `person_country` at the gate.

**United States, CAN-SPAM.** Cold B2B email is permitted without prior consent. The obligations sit on the message: accurate From and Reply-To, no deceptive subject line, a real physical postal address, a working and honoured opt-out, and opt-outs processed promptly. A purchased or scraped list is legal to email and still has to honour every one of those.

**EU, UK and EEA, GDPR plus the ePrivacy rules.** Different in kind, not degree. Two separate questions.

1. Processing the data at all. Scraping and storing a named person's work email is processing personal data and needs a lawful basis. Legitimate interest is the usual one for B2B, and it is only available if the offer is genuinely relevant to that person's job, the volume is proportionate, and the person can object easily.
2. Sending the message. National rules differ, and several member states are stricter for email marketing than the baseline. Individual sole traders and personal addresses get more protection than a role at a limited company.

Practical consequences for the build:

- A `person_country` inside the EU, UK or EEA means the row needs a written relevance note, not just a title match.
- Never scrape a personal address (`personal_domain`) for an EU or UK contact.
- Keep the source and date for every row. A subject access or objection request cannot be answered without them.
- The message needs a plain identity, a plain reason for contact, and a one-click objection route.
- Do not carry data you have no use for. Photo URLs, follower counts and personal city rarely earn their place. Drop them.

**Everywhere else.** Assume the stricter of the two until the operator confirms otherwise. Canada's CASL is consent-based and stricter than CAN-SPAM. Say what you assumed.

> [!important] The one thing never to do
> Never present a compliance judgement as settled. Flag the geography split, state what the build did, and say plainly that the legal call belongs to the operator and their counsel.

## Suppression, before anything is sent

Run these three checks at the gate, in this order:

1. **Unsubscribes and objections.** Anyone who has ever opted out, across every sending tool, not just the one being used now.
2. **Hard bounces.** A previously bounced address that reappears from a new source is still a bounce.
3. **Existing CRM records and open deals.** The `already_in_crm` flag.

A suppression list that lives inside one sending tool is not a suppression list. Ask for the export and keep it with the campaign.

## Deliverability, decided at list build

Most deliverability damage is done before a single email is written, by the list.

- **Bounces are the killer.** Mailbox providers read bounce rate as a spam signal. This is the whole reason `invalid_email` is a hard flag rather than a preference.
- **Catch-all is unproven, not safe.** A catch-all server accepts everything, so an accepted address tells you nothing. Never let catch-all rows sit in the main list.
- **Role addresses attract complaints.** Shared inboxes are read by people who did not ask for the mail, and they mark it as spam more often.
- **Volume per domain matters.** A tiny company receiving four separate cold emails from one sender reads as a blast to both the recipient and the filter. This is why `duplicate_company` exists.
- **List size is not a target.** A verified list of 40 outperforms an unverified list of 400 and does not cost the domain.

What belongs in the handover to the sending step, and does not belong here: warmup, sending volume ramp, SPF, DKIM and DMARC records, inbox placement testing, and whether the campaign sends from the primary domain or a separate one. Name them so nobody assumes the list build covered them.

## The line to put in every final report

> Geography split: how many rows in each regime. Suppression: which lists were checked and which were unavailable. Verification: who verified, and the result counts. Sending controls are not covered by this skill.
