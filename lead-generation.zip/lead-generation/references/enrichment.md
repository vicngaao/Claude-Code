# Enrichment and verification

After sourcing and qualification you have companies and people but often not their contact details, or details you cannot trust. Enrichment finds the email and phone; verification proves the email is real. The non-negotiable rule: **only verified emails move forward.** A campaign sent to unverified addresses bounces, and bounces wreck sender reputation, which is the one asset a cold channel cannot operate without.

## Order of operations

1. **Dedup first.** Collapse duplicate people and duplicate domains before any paid call. Paying twice for the same record is pure waste.
2. **Find the email** by full name + company domain.
3. **Find the phone** (only if the campaign uses calling/WhatsApp).
4. **Verify the email.** Keep verified; drop or quarantine the rest.
5. **Casualize the company name** for natural personalization downstream.

## Email finders

Default to AnyMailFinder; switch by config or availability. In vault mode the chosen provider is in `Context/config.md` / `Context/stack.md`.

> [!important] Check the source actor before you route out to a provider
> The Apify Google Maps actor's `maximumLeadsEnrichmentRecords` add-on returns the person, their title, their work email, their mobile and their LinkedIn profile in the same run that sourced the place, and `verifyLeadsEnrichmentEmails` verifies each address in the same pass. When a dedicated finder is unreachable, that add-on is the working fallback for both steps, not a downgrade to be apologised for. Full ladder in `fallbacks.md`. Whichever route you use, name it in the final report.

| Provider | Strength | Notes |
| --- | --- | --- |
| **AnyMailFinder** (default) | Verified-email-first billing; bulk API | You are billed mainly for emails it can verify, which keeps cost tied to usable output. Bulk endpoint takes `[domain, first, last]` rows; poll for results. Falls back gracefully when an email cannot be found. |
| **Apollo** | Email + mobile in one credit system | Good when you also want phone and firmographics; credit-metered. |
| **Prospeo** | Mobile/phone + LinkedIn-email | Strongest for phone numbers and for resolving an email from a LinkedIn URL. |

**Input you need:** a clean company domain (not a personal domain) and the person's first/last name. Filter out personal email domains before lookup, there is no company email to find behind gmail.com. Personal-domain filter list:
```
gmail.com, yahoo.com, hotmail.com, outlook.com, live.com, aol.com, icloud.com, me.com, mail.com,
protonmail.com, zoho.com, yandex.com, gmx.com, fastmail.com, msn.com, qq.com, 163.com, naver.com,
mail.ru, web.de, gmx.de, orange.fr, free.fr, ymail.com, comcast.net, att.net, bigpond.com
```

## Phone

Use Prospeo (or Apollo) only when the cadence includes a call or WhatsApp step. Phone enrichment is more expensive and lower-hit-rate than email; do not pull it by default.

## Verification gate

- Keep only addresses the finder marks verified/valid (sometimes called "deliverable", "safe", or `ok`).
- "Catch-all", "risky" or "accept-all" addresses are a judgement call: include them only in a separate, clearly-labeled segment, never in the main verified list, since they inflate bounce risk. A catch-all server accepts every address, so acceptance proves nothing.
- Records with no findable verified email are dropped from the email campaign (they can still feed a LinkedIn-only or phone-only cadence in `outreach`).
- Report the find-rate and verify-rate. A low find-rate usually means a bad domain column or wrong names from the source, fix upstream rather than shipping a thin list.

> [!warning] Verification is not validation
> A verifier proves a mailbox exists. It does not prove the person still works there, that the title is current, or that the company on the row is the one they work for. Enriched Maps data routinely returns an address that verifies `ok` on a domain that is not the company's domain, because the record is stale and the database kept the old employer. That is why the hygiene gate carries a `domain_mismatch` flag alongside the verifier result. Verification is one flag of thirteen, not the finish line. See `hygiene-gate.md`.

## What to add while you are here

Four columns that cost nothing now and cannot be reconstructed later: `source`, `sourced_at`, `person_country`, and `verified_at`. They are what makes the list defensible and debuggable. See `compliance-and-deliverability.md`.

## Casualize company names

Strip legal suffixes (Inc, LLC, Ltd, Pvt Ltd, GmbH, BV, Corp, Co), trademark marks, and location noise that is not part of the brand, so "Jonathan Williams Inc" becomes "Jonathan Williams". A casual name reads human in an icebreaker; the legal name reads like a mail merge. Use the domain as a hint when the brand is ambiguous. This can run as one batched LLM pass over all companies.

## Output of this phase

The list now carries, per lead: verified `email` (and `phone` when pulled), a verification status, a casual company name, and the four provenance columns, on top of the qualification columns. Persist it to disk, then run the hygiene gate before Phase 6. Researching a row that will not survive the gate is the most expensive mistake in the pipeline.
