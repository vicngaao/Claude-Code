# Fallbacks: what to do when a tool is not there

This skill has no hard dependency. Every job it does has at least two routes, and the routes were tested rather than assumed. Read this the moment a preflight check fails, before telling the operator anything is blocked.

The rule: **a missing tool changes the route, never the standard.** Verification still happens. Deduplication still happens. The hygiene gate still runs. What changes is which service performs the step.

And the route never changes silently. Propose the fallback to the operator with the reason and the cost difference, get a yes, then take it. The ladders below are a menu of proposals, not permission to proceed. This applies mid-run too: a source swap, a coverage cut, or a provider swap all stop the run until the operator approves.

## The two floors

Everything below reduces to one of two floors. If either is present, a run can complete.

- **Apify floor.** One connector covers sourcing, contact enrichment, decision makers and email verification, because the Google Maps actor now bundles all four. See the ladders below.
- **Firecrawl floor.** Search plus a schema driven scrape covers sourcing from any public directory, and the company site covers contacts. Slower on people data, but it needs nothing else.

If neither is present, say so plainly and stop. That is the only genuine block in the whole skill.

## Ladder 1: finding the leads

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| Apify actor for the source (Maps, LinkedIn, niche) | Firecrawl search to find the index page, then a schema driven Firecrawl scrape over it | Ask the operator for an export they already have and start at qualification |

## Ladder 2: Sales Navigator

Source B1 needs a Sales Navigator seat plus a scrape route. When the scrape route is missing:

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| Sales Navigator search, scraped | Apify LinkedIn lead finder actors with the same filters mapped to the actor's input | Ask for a Sales Navigator CSV export and start at qualification |

Say which one you used. The Apify route has coarser targeting than Sales Navigator's own filters, and the operator should know their list was built on the coarser filters.

## Ladder 3: finding the email

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| A dedicated email finder (AnyMailFinder, Prospeo, Apollo) | The Apify source actor's own leads enrichment add-on, which returns work email with the person | The company website contact pass, which returns role addresses only |

The website pass is a genuine last resort. It produces `role_address` flags, so most of what it finds will not survive the hygiene gate. Tell the operator that before spending time on it.

## Ladder 4: verifying the email

This is the ladder that matters most, because the standard is absolute: an unverified address never ships.

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| The email finder's own verification result | The Apify actor's email verification add-on, which returns `ok`, `catch_all` or `invalid` per lead | No verifier at all |

With no verifier at all, the run does not ship an email list. It ships a phone or LinkedIn list, and says explicitly that email was withheld because nothing could verify it. Never relabel unverified as verified, and never quietly drop the gate.

## Ladder 5: phone

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| Prospeo or Apollo | The Apify leads enrichment mobile field, when present | The company switchboard number from the source, clearly labelled as a company number rather than a direct line |

A switchboard number is not a mobile. Label the column so nobody dials it expecting the decision maker.

## Ladder 6: deduplicating against the CRM

| Preferred | Fallback | Last resort |
| --- | --- | --- |
| The CRM connector, matched on domain then on email | A CSV export of the CRM, matched the same way | Ask the operator to confirm no overlap, and record that no check was run |

Never skip this silently. `already_in_crm` is the flag most likely to cause real damage, because it puts a cold sequence in front of an account somebody already owns.

## Ladder 7: subagents

| Preferred | Fallback |
| --- | --- |
| The purpose built agent types, when the sales plugin is installed | `general-purpose` subagents with the same verbatim instructions, same batch sizes, same output paths |

The fallback is not a downgrade. The instructions carry the behaviour, not the agent type.

## Ladder 8: delivery

| Preferred | Fallback |
| --- | --- |
| Google Sheet via the `gws` CLI | CSV on disk, and say up front that no Sheet was created |

## Reporting a fallback

Whenever a fallback was used, the final report carries one line per substitution, in this shape:

> Email verification: the configured finder was unreachable, so verification ran through the Apify actor add-on. 32 leads checked, 10 returned `ok`, 14 `catch_all`, 5 `invalid`, 3 had no address.

An operator who does not know which route produced their list cannot judge it. This line is not optional.
