# The hygiene gate: would you act on this lead?

Every phase before this one adds rows. This one removes them. It runs after enrichment and before research, because researching a row you will never contact is the most expensive mistake in the whole pipeline.

The gate is not a vibe check. It is a fixed set of flags, computed by script over the merged file, one column per flag and one verdict column. A row ships only when it carries zero flags. Print the flag counts, always, so the operator can see what the list cost them and widen a specific gate on purpose instead of by accident.

## Why a script and not judgement

Three reasons, all learned from real runs.

1. A model reading 300 rows will miss duplicates that differ by one character.
2. Counts have to be reproducible. "43 rows" has to mean 43 every time someone re-runs it.
3. The operator needs to argue with a named rule, not with your taste.

## The flags

Compute all of them. Never skip one because it looks unlikely.

| Flag | Test | Why the row is not actionable |
| --- | --- | --- |
| `no_email` | No email found | Nothing to send to. Can still feed a phone or LinkedIn cadence |
| `invalid_email` | Verifier returned invalid, undeliverable, or no mailbox | A guaranteed bounce. Bounces are what get a domain blocked |
| `catch_all` | Verifier returned catch-all or accept-all | The server accepts everything, so the address is unproven. Segment it separately, never in the main list |
| `personal_domain` | Email domain is in the free-provider list | No company mailbox behind it, and usually the wrong person |
| `role_address` | Local part is `info`, `hello`, `sales`, `contact`, `support`, `admin`, `careers`, `office`, `enquiries`, `team` | A shared inbox, not a person. Personalization is impossible and reply rates collapse |
| `domain_mismatch` | Email domain does not match the company domain on the row | Almost always a stale record: the person moved and the database kept the old company |
| `duplicate_person` | Same normalized name plus same company domain appears more than once | You would contact one human twice |
| `duplicate_email` | Same email appears more than once | Same, and it doubles your enrichment bill |
| `duplicate_company` | Same company domain appears more than the per-company cap | Two people at a nine-person company reads as a blast |
| `below_target_seniority` | Seniority is below the tier the ICP asked for | Cannot buy, and forwarding rarely happens |
| `outside_target_geo` | Person country or region is outside the ICP geography | The department filter leaked. Common with offshore staff on a local company |
| `already_in_crm` | Matches an existing CRM record | Working an owned account cold is the fastest way to lose it |
| `suppressed` | Matches an unsubscribe, bounce, or do-not-contact list | Legal exposure and reputation damage |

## The traps behind the flags

Verification proves a mailbox exists. It does not prove the person still works there, that the title is current, or that the company is the one on the row. That is why `domain_mismatch` exists alongside a verifier: a stale record can verify perfectly and still be worthless. A row that verifies `ok` on a domain that is not the company's domain is the single most common false positive in enriched Maps data.

A department is not a seniority. Filtering a source to "marketing" returns the marketing intern as readily as the CMO. Always apply a seniority test after the source filter, never instead of it.

A scraped website contact page is a staff list, not a lead list. Sixteen addresses off one site is sixteen role addresses and juniors, not sixteen prospects.

## Personal-domain list

```
gmail.com, yahoo.com, hotmail.com, outlook.com, live.com, aol.com, icloud.com, me.com, mail.com,
protonmail.com, proton.me, zoho.com, yandex.com, gmx.com, gmx.de, fastmail.com, msn.com, qq.com,
163.com, naver.com, mail.ru, web.de, orange.fr, free.fr, ymail.com, comcast.net, att.net, bigpond.com
```

## Role-address local parts

```
info, hello, hi, sales, contact, contacts, support, help, admin, office, enquiries, enquiry,
inquiries, careers, jobs, hr, recruiting, team, marketing, press, media, billing, accounts,
accounting, finance, legal, privacy, webmaster, postmaster, noreply, no-reply, newsletter
```

## Output of the gate

Three files, always, so nothing is silently thrown away:

- `leads_actionable.csv`. Zero flags. This is the list.
- `leads_quarantined.csv`. Everything with at least one flag, with the flags in a column. Reviewable, and the source of a widened gate if the operator wants one.
- `hygiene_report.md`. The counts table, the flag counts, and one named example per flag. This is what you show the operator.

Report the survival rate as a plain fraction: rows in, rows out. If the survival rate is under about a fifth, the problem is upstream in the source or the filters, not in the gate. Say so and offer to re-source rather than shipping a thin list.

## What the operator is allowed to widen

Only two flags are a judgement call, and only with the operator saying so out loud:

- `catch_all`, into a separate clearly labelled segment sent from a separate domain.
- `duplicate_company`, when the cap is deliberately more than one contact per account.

The rest are not preferences. An invalid address, a suppressed contact, or a person already owned in the CRM is never a widening decision.
