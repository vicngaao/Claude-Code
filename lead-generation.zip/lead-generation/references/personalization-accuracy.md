# Personalization accuracy: the claims a prospect can check

Every personalized line is a claim. The ones that name a competitor, a distance, a
review count or a person are claims the recipient can verify in about ten seconds,
from their own phone, before they decide whether to reply. A wrong one does not just
fail to land - it tells them the email was generated.

These are the failures that actually occurred on a real 53-lead run, in the order
they cost the most.

## 1. Verify against the source, never against your own output

The pipeline's own personalization file is not evidence. Re-derive every claim from
the raw scrape, keyed on the stable id, and diff the two.

On the run that prompted this, that pass confirmed 53 of 53 ratings and review counts
and still found four separate defects nothing else caught. A QA script that reads the
same file that produced the copy will always agree with itself.

Check, at minimum:

- rating and review count against the raw source row
- the qualification floors still hold (a row that drifted below the bar)
- the central claim of the pitch is still true in the source
- every external URL still responds
- every computed number recomputes to the same value

## 2. Route with a traffic-aware router, and quote TIME

If the copy states how far something is, state it in **minutes**, not kilometres. The
prospect drives that route; they do not measure it.

Free routers are not safe here. OSRM's public endpoint uses free-flow speeds and models
no signals. Measured on 53 real Indian-metro routes against Google Distance Matrix:

| router | median | max |
|---|---|---|
| OSRM | 2.3 min | 10.2 min |
| Google (typical) | 5.8 min | 18.6 min |

Roughly a 2.5x understatement. Fine for shortlisting by proximity. Not fine in a
sentence the recipient can check.

**Do not send a `departure_time`.** With it the router re-picks against live traffic and
stops being reproducible: the same coordinate pair returned 4.8 km / 13 min on one call
and 1.9 km / 7 min minutes later. A number saved in an email must not move, and a
verification pass has to be able to recompute it and agree. Ask for the typical-conditions
route instead.

Record which router produced each number - a figure whose origin is not written down
cannot be defended later.

**Never round a number upward to sound better.** An invented minute is an invented fact.

## 3. When the listing is a person, write "you"

Many local listings are simply the owner's name. Writing

> I noticed Ramprasad T Solanke has 191 reviews

to Ramprasad reads like a mail merge narrating him in the third person.

> I noticed **you have** 191 reviews

This applied to 30 of 53 leads on one run. Detect it on the **short name that will
actually appear in the sentence**, not on the full source title. This is easy to get
backwards: `Sushant J Tayade & Associates` is a firm by its title, but the copy writes
the shortened `Sushant J Tayade`, and that is what the recipient reads. Guard it with a
match against the known principal, so a short trading name cannot silently flip to
second person. A firm marker (Associates, Legal, Chambers, LLP, Solicitors, Services,
& Co) means firm; honorifics and parentheticals do not.

Clean the short name **before** this test. Shorteners leave artefacts, and the same
string usually feeds the subject line, the body and the test, so one artefact reaches
the prospect three times.

When genuinely unsure, prefer "you". Calling a firm "you" still reads fine because a
human being opens the email either way. The reverse reads broken.

## 4. Canonicalise every value you count

`Justdial` and `justdial` counted as two platforms and split the frequency table that
drives a merge variable. Normalise case and spelling before counting anything that
reaches the copy or a report. On one run this collapsed 99 apparent platforms to 92.

## 5. Re-check external URLs immediately before delivery

A competitor site, a company homepage, a LinkedIn profile: all can die between build and
send. One of 53 went dead in under a day, about 2%. Run the reachability sweep as the
last step before export, not once at build time, and substitute rather than ship the
dead reference.

## 6. Read the generated copy as prose

Template output produces grammar that no reviewer of the data would catch, because the
data is right. Real examples: `a 8-minute drive` (article agreement), `0.0 km from you`
(a true number that reads like a bug), a salutation of `Adv. Partner)` from an unstripped
parenthetical.

Print a handful of complete, assembled messages and read them as a recipient would. This
is a separate pass from the data QA and catches a different class of defect.

## 7. Dedupe against everything you have already sent

A second run over overlapping geography returns the same companies. On one repeat
run **12 of 53** leads were already in the earlier batch, and the overlap was
concentrated rather than spread: the two cities worked previously dropped from 6
and 9 leads to 1 and 2.

Match on **four keys** - stable id, email, phone and a normalised name. The id
proves it, but a business re-scraped under a slightly different title comes back
with a fresh id. Two of those 12 matched on the id and on nothing else, so a
name-only or email-only check would have sent the same opener twice.

Run it against the **live** prior list, not a local snapshot: the snapshot is what
you generated, the live sheet is what the operator actually sent from. Write the
removals to their own file with the key that matched, so a wrong exclusion is
recoverable.

Plan sourcing around it. Either target geography you have not worked, or expect to
discard most of a repeated city.
