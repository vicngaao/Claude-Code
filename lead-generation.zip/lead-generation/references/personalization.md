# Personalization: levels, variables, and the research each one buys

Personalization is defined **before** the run, not after, because it decides what Phase 4 researches and which columns the final list carries. A list built without knowing the templates cannot be upload-ready; the variables would be missing.

## The method: variable-based personalization

The user writes the copy. The pipeline fills only the variables. Claude never writes full emails in this pipeline; a human-written template with machine-filled variables outperforms machine-written prose and keeps the voice consistent at volume.

So the sequence is:
1. Ask the user for their template(s). A cadence may carry six or seven pieces of copy across channels (email 1, email 2, LinkedIn DM 1, WhatsApp 1, call opener). Collect all of them.
2. Extract every `{variable}` from every template. The union of variables across all templates is the set of columns the final list must carry.
3. For each variable, agree the research recipe (below) and a **fallback**: what fills the slot when research finds nothing. A fallback is usually a level down the ladder (no LinkedIn post found, fall back to job title) or a neutral phrase. A blank variable must never reach the sending tool.

If the user has no template yet, show the levels below, recommend from the best practices, and have them write one before Phase 4 starts. Different steps of the cadence can use different personalization; note which variable belongs to which template.

## The levels ladder

Ordered roughly from cheapest to deepest. Depth costs research time; recommend the deepest level the user's volume and budget can afford, because reply rate follows perceived effort.

| Level | Variable example | Research needed | Source |
| --- | --- | --- | --- |
| First name | `{first_name}` | None, comes from sourcing | Scrape |
| Casual company name | `{company}` | Strip legal suffixes, normalize | Script / enrichment pass |
| Job title / role | `{role_phrase}` | None to light | Scrape |
| LinkedIn post hook | `{recent_post_topic}` | Person's 2 most recent posts | LinkedIn post scraper |
| Competitor name drop | `{competitor}` | Who their direct or local competitor is | Web research per lead |
| Case study match | `{case_study}` | Their site + LinkedIn for a named client story that mirrors the user's own case study | Website + company LinkedIn |
| Secondary decision maker | `{colleague_name}` | A second named person at the company (e.g. the CEO when writing the sales director) | Company people lookup (LinkedIn company employees actor, or Maps leads add-on) |

Engagement-based hooks (the lead commented on a post; quote it back) sit at the top of the ladder when the source provides them: the research is already done at scrape time.

## Best practices, field-tested

- **One deep variable per message.** Stacking three researched claims into one email reads like a mail merge trying too hard. One sharp hook plus first name and company beats a collage.
- **The hook must survive a truth check.** Every researched claim is re-derived from the raw source before send (see `personalization-accuracy.md`). A wrong competitor name is worse than no personalization.
- **Fallback chains, always.** Define them per variable at interview time: post hook -> role phrase -> generic opener. The pipeline fills the deepest level it can prove.
- **Personalization varies by niche.** A local gym owner responds to a review quote or a local competitor; a SaaS VP responds to a funding or hiring signal. Recommend by ICP, do not apply one recipe to everything.
- **Per-touch personalization.** Email 1 can carry the deep hook while WhatsApp 1 carries only first name. Research once, reuse across touches.

## What this means for Phase 4

Build the research task list directly from the variable set:
- `{competitor}` chosen -> researchers identify one true competitor per lead (direct, local, or category, as agreed).
- `{case_study}` chosen -> researchers scan the lead's site and company LinkedIn for named client stories.
- `{colleague_name}` chosen -> run a people lookup per company, filtered to the agreed title.
- `{recent_post_topic}` chosen -> run the LinkedIn posts scraper over the lead list in one batched call.
- Only scrape what a chosen variable needs. Research nobody asked for is spend without a column.

## Output contract

Phase 5's list carries one column per variable, named exactly as the template names it, plus a `personalization_level_used` column when fallback chains exist, so the user can see which leads got the deep version. The list uploads to Instantly or Smartlead as-is; the sending tool does the mail-merge.
