# Generating the use-case skill (Phase 6)

The generated skill is the product of the whole run. It freezes a proven configuration so the next run is one command. Two preconditions before writing anything: the user said yes to the offer (never generate unasked), and the `skill-creator` skill is invoked to do the authoring when it is installed. This file is the content spec the generated skill must satisfy; skill-creator supplies the craft: lean, imperative, explains why, under 500 lines, with a description that triggers reliably.

## Where and what

- Path: `~/.claude/skills/<use-case-slug>/SKILL.md` (the filename is exactly `SKILL.md`).
- Name: the use case, kebab-case, specific. `fintech-unicorns`, `saas-sales-hiring`, `linkedin-post-engagers`. Never `leads-v2` or `my-pipeline`.
- If the run produced helper scripts the next run will need verbatim (a qualification filter, a merge script), bundle them in `<slug>/scripts/` and reference them from the SKILL.md instead of pasting long code inline.

## Frontmatter rules

```yaml
---
name: <slug>
description: >-
  <What it does in one sentence, then when to use it. Make it pushy: list the
  user phrases that should trigger it, including casual ones. All "when to use"
  language goes here, not in the body.>
---
```

Only `name`, `description`, and optionally `allowed-tools`, `license`, `metadata`, `compatibility` are allowed keys. `name` and `description` are required.

## The template

The generated skill mirrors the parent pipeline, with everything decided replaced by the decision. Structure:

```markdown
# <Use Case Name>

One paragraph: what this pipeline produces, for which ICP, and that it was
generated from a proven lead-generation run on <date>.

## Locked configuration
The decisions this skill was built on. Change them by re-running the
lead-generation skill, not by improvising mid-run.
- Offer: ...
- ICP: ...
- Source and tool: <exact actor/tool + the input filters as a JSON block>
- Qualification, scriptable: <the exact rules, ideally the actual filter logic>
- Qualification, research-based: <the exact question subagents answer per lead>
- Who we contact: <titles/seniority>
- Cadence and required contact points: ...
- Enrichment providers per data point, with fallbacks: ...
- Personalization variables and the research recipe per variable: ...
- Templates: <inline or a pointer to where they live>
- Delivery: <Sheet/CSV, column order>

## Ask before running
Only what changes between runs: volume, geography, date cutoffs, anything the
user flagged as variable. Everything else is locked.

## Pipeline
Step 1: Scrape        <exact call, test batch, over-pull math>
Step 2: Pre-qualify   <script filter first; subagent batch-10 for the research
                       pile; the subagent gathers research while qualifying>
                      CHECKPOINT: show the qualified list, wait for a confirm.
Step 3: Enrich        <provider per data point; verify; hygiene gate; the
                       partial-data question>
Step 4: Research      <batch-5 subagents, scoped to the variable set>
Step 5: Deliver       <upload-ready list: contacts + one column per variable>

## Operating rules
Copy the parent's "Operating rules that always apply" list, dropping any that
cannot apply to this source.

## Technical patterns
The Apify two-step call, timeout recovery, sampling before download, and any
source-specific gotchas discovered during the run (field names, URL format
mismatches, fuzzy-matching thresholds). This is where run-time learning is
banked so the next run does not rediscover it.
```

## Writing rules (from the skill-creator)

- Imperative voice. Explain why a rule exists instead of shouting MUST.
- Keep it under 500 lines. Push long code and long tables into `scripts/` or a `references/` folder inside the generated skill.
- Include real examples from the run (an actual input block that worked, an actual field-name mismatch found) because they carry more information than abstract instructions.
- The description is the trigger. Include what the skill does AND the phrases a user would say, erring on the side of pushy; skills undertrigger by default.
- No secrets. API keys stay in environment variables; the skill references the variable name (`$PROSPEO_API_KEY`), never a value.

## Validate before handing over

1. Frontmatter parses, only allowed keys, name matches the folder.
2. If the skill-creator skill is installed, run its validator:
   `python3 ~/.claude/skills/skill-creator/scripts/quick_validate.py <skill-folder>`
3. Read the generated skill once end to end as if you were the next session: could you run the pipeline from this file alone, with no memory of the conversation that built it? If not, the missing context goes in now.
4. Tell the user the skill's name, its path, and an example invocation phrase. Offer to run the skill-creator's eval loop on it later if they want it battle-tested.
